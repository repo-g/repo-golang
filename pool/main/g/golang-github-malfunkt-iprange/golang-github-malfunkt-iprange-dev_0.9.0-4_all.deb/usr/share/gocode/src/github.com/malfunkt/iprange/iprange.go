//go:generate -command yacc go tool yacc
//go:generate yacc -p "ip" ip.y

package iprange
