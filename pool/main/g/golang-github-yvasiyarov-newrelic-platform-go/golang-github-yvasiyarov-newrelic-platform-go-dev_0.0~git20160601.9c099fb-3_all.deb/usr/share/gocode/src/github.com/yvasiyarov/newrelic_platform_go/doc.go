// Package newrelic_platform_go is New Relic Platform Agent SDK for Go language.
package newrelic_platform_go
