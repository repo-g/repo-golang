// Package wifi provides access to IEEE 802.11 WiFi device operations on Linux
// using nl80211.
package wifi
