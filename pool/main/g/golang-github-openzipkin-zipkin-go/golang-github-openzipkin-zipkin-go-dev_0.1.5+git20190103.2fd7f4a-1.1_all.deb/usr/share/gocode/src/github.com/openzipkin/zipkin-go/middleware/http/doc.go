/*
Package http contains several http middlewares which can be used for
instrumenting calls with Zipkin.
*/
package http
