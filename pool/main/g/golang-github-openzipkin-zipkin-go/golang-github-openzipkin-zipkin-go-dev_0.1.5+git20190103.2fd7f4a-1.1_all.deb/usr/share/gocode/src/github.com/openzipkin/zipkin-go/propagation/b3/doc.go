/*
Package b3 implements serialization and deserialization logic for Zipkin
B3 Headers.
*/
package b3
