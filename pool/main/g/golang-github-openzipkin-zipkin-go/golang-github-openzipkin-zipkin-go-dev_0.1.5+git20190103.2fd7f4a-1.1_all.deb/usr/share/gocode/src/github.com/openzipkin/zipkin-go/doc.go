/*
Package zipkin implements a native Zipkin instrumentation library for Go.

See https://zipkin.io for more information about Zipkin.
*/
package zipkin
