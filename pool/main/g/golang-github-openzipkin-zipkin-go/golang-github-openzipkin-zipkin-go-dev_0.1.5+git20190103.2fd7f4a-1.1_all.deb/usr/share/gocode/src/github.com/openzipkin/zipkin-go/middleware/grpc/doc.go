/*
Package grpc contains several gRPC handlers which can be used for instrumenting calls with Zipkin.
*/
package grpc
