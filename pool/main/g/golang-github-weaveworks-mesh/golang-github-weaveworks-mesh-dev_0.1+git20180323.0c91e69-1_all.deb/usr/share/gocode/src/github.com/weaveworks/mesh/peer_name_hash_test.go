// +build peer_name_hash

package mesh_test

import "testing"

func TestHashPeerNameFromUserInput(t *testing.T) {
	t.Skip("TODO")
}

func TestHashPeerNameFromString(t *testing.T) {
	t.Skip("TODO")
}

func TestHashPeerNameFromBin(t *testing.T) {
	t.Skip("TODO")
}
