package mesh_test

import "testing"

func TestRoutesUnicast(t *testing.T) {
	t.Skip("TODO")
}

func TestRoutesUnicastAll(t *testing.T) {
	t.Skip("TODO")
}

func TestRoutesBroadcast(t *testing.T) {
	t.Skip("TODO")
}

func TestRoutesBroadcastAll(t *testing.T) {
	t.Skip("TODO")
}

func TestRoutesRecalculate(t *testing.T) {
	t.Skip("TODO")
}
