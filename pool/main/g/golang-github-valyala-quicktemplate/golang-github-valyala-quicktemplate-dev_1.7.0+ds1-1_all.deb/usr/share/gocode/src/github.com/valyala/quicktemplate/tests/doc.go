// Package tests contains tests for quicktemplate
package tests
