package quicktemplate

//go:generate qtc -dir=testdata/templates
