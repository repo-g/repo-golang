// Package cwriter is a console writer abstraction for the underlying OS.
package cwriter
