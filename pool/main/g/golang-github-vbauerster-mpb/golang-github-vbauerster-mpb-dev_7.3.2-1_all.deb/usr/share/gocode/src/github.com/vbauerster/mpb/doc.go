// Package mpb is a library for rendering progress bars in terminal applications.
package mpb
