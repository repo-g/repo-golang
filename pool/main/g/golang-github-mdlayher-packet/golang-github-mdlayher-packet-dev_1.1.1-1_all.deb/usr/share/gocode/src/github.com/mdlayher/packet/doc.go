// Package packet provides access to Linux packet sockets (AF_PACKET).
package packet
