// Package nethttp provides OpenTracing instrumentation for the
// net/http package.
package nethttp
