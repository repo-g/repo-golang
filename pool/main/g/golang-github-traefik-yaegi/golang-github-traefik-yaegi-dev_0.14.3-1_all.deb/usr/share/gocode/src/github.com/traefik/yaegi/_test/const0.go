package main

const (
	a = iota
	b
)

func main() {
	println(a, b)
}

// Output:
// 0 1
