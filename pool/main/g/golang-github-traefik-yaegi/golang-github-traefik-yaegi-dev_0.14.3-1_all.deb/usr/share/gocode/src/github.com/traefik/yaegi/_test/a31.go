package main

func main() {
	for range []int{0, 1, 2} {
		print("hello ")
	}
	println("")
}

// Output:
// hello hello hello
