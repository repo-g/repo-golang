package main

import . "fmt"

func main() {
	Println("Hello", 42)
}

// Output:
// Hello 42
