package main

import f "fmt"

func main() {
	f.Println("Hello", 42)
}

// Output:
// Hello 42
