package main

import "fmt"

func main() {
	fmt.Println("Hello", 42)
}

// Output:
// Hello 42
