package main

const a, b, c int = 1, 2, 3

func main() { println(a, b, c) }

// Output:
// 1 2 3
