package main

var f = func(a int) int { return 2 + a }

func main() {
	println(f(3))
}

// Output:
// 5
