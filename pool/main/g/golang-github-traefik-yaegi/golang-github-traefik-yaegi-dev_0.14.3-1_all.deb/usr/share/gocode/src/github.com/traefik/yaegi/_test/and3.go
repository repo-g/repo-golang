package main

var a = true && true

func main() {
	println(a)
}

// Output:
// true
