package main

import "fmt"

func main() {
	fmt.Println(false, true)
}

// Output:
// false true
