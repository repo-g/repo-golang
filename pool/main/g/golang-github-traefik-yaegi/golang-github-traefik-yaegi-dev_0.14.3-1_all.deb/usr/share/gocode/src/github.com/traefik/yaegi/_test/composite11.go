package main

import (
	"fmt"
	"image/color"
)

func main() {
	c := color.NRGBA64{1, 1, 1, 1}

	fmt.Println(c)
}

// Output:
// {1 1 1 1}
