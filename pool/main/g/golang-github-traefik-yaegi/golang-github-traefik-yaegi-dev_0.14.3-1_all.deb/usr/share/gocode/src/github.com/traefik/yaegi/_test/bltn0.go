package main

func main() {
	f := println
	f("Hello")
}

// Error:
// 4:7: use of builtin println not in function call
