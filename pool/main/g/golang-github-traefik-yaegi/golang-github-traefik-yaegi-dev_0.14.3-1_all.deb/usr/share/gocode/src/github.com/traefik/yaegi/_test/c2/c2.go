package c2

import "github.com/traefik/yaegi/_test/c1"

var C2 = c1.C1 + "Y"
