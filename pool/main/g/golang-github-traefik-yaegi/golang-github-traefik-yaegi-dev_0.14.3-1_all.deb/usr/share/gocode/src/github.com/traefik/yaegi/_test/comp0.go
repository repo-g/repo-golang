package main

func main() {
	println(2 < 2.4)
}

// Output:
// true
