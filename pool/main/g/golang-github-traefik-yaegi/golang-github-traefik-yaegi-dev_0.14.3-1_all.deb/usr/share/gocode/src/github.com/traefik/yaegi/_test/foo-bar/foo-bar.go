package bar

var Name = "foo-bar"
