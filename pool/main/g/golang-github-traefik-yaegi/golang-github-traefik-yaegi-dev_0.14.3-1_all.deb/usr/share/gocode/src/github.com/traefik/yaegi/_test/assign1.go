package main

import "fmt"

func main() {
	var buf []byte

	buf = nil
	fmt.Println(buf)
}

// Output:
// []
