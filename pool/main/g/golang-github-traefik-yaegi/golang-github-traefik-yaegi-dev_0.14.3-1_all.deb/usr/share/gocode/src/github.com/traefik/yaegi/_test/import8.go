package main

import "github.com/traefik/yaegi/_test/b1/foo"

func main() {
	println(foo.Desc)
}

// Output:
// in b1/foo
