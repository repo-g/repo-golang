package foo

var Desc = "in b2/foo"
