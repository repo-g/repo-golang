package main

func main() {
	a := 0
	b := false
	if (b) {
		a = 1
	} else {
		a = -1
	}
	println(a)
}

// Output:
// -1
