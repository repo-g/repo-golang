package main

import "github.com/traefik/yaegi/_test/p1"

func main() { println("num:", p1.Uint32()) }

// Output:
// num: 2596996162
