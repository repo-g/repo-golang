package main

func main() {
	println("Hi")
	goto done
done:
}

// Output:
// Hi
