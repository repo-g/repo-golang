package main

import "time"

func main() {
	time.Date()
}

// Error:
// 6:2: not enough arguments in call to time.Date
