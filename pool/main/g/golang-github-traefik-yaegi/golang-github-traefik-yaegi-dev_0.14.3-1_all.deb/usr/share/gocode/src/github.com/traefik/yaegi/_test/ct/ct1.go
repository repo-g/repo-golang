package ct

func init() { println("hello from ct1") }
