package main

func f(i int64) {
	println(i)
}

func main() {
	f(34)
}

// Output:
// 34
