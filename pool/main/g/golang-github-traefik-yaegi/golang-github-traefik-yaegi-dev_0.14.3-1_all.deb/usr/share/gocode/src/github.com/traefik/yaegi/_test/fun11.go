package main

var f F

type F func(int)

func main() {
	println("ok")
}

// Output:
// ok
