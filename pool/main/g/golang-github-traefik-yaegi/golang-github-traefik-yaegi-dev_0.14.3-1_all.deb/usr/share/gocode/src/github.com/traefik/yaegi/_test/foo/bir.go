package foo

import "github.com/traefik/yaegi/_test/foo/boo"

var Bir = boo.Boo + "22"
