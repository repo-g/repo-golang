package main

func main() {
	_ = 1
	println(1)
}

// Output:
// 1
