package main

import "fmt"

func main() {
	var s uint = 4
	t := make([]int, s)
	fmt.Println(t)
}

// Output:
// [0 0 0 0]
