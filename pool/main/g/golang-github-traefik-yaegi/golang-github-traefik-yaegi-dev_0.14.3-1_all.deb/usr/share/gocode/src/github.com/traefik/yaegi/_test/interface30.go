package main

func main() {
	var a interface{}
	println(a != nil)
}

// Output:
// false
