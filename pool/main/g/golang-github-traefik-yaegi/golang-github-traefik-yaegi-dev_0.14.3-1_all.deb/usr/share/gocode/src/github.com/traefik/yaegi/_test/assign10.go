package main

func main() {
	var a uint
	a = 1 + 2
	println(a)
}

// Output:
// 3
