package main

type Number = int

func main() {
	println(Number(1) < int(2))
}

// Output: true
