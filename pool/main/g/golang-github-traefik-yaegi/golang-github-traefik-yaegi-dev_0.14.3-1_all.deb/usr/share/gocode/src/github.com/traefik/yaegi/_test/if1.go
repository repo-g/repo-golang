package main

func main() {
	i := 1
	if i > 0 {
	}
	println("bye")
}

// Output:
// bye
