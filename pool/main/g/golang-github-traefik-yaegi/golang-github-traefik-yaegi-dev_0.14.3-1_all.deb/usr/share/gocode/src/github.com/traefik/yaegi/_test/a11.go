package main

func main() {
	a := []int{1, 2, 3, 4}
	for _, v := range a {
		println(v)
	}
}

// Output:
// 1
// 2
// 3
// 4
