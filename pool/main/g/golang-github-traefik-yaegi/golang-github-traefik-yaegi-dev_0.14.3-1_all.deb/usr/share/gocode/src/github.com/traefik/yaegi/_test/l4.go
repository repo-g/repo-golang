package main

func main()       { println(f(5)) }
func f(i int) int { return i + 1 }

// Output:
// 6
