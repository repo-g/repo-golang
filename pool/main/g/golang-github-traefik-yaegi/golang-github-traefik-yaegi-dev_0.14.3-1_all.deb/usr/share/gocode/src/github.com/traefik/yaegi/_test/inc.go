package main

func main() {
	i := 2
	//i++
	i = i + 1
	println(i)
}

// Output:
// 3
