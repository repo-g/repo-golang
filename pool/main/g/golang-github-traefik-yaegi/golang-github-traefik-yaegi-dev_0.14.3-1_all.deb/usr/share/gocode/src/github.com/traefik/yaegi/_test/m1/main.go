package main

import (
	"fmt"
	"testing"
)

func main() {
	fmt.Println("vim-go")
}

func TestWeird(t *testing.T) {
	fmt.Println("in TestWeird")
}
