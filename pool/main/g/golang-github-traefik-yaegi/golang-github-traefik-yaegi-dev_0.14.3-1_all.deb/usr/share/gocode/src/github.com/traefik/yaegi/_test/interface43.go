package main

import "fmt"

func main() {
	v := interface{}(nil)

	fmt.Println(v)
}

// Output:
// <nil>
