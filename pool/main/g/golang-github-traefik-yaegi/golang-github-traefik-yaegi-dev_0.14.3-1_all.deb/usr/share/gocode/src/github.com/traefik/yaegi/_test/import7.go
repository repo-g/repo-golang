package main

import bar "github.com/traefik/yaegi/_test/foo-bar"

func main() {
	println(bar.Name)
}

// Output:
// foo-bar
