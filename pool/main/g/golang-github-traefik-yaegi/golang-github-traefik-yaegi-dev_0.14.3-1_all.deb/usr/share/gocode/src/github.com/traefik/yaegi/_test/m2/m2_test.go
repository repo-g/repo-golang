package m2

import "testing"

func TestM2(t *testing.T) {
	t.Errorf("got %s, want %s", "AAA", "BBB")
}
