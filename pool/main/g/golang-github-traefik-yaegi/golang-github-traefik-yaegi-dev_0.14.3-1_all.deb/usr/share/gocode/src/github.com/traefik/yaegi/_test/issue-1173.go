package main

var real = func() { println("Hello") }

func main() {
	real()
}

// Output:
// Hello
