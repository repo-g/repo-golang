package main

func main() {
	var a bool

	for a {
		println("nok")
		break
	}
	println("bye")
}

// Output:
// bye
