package d2

import "github.com/traefik/yaegi/_test/d1"

var (
	X = d1.NewT("test")
	F = X.F
)
