package main

import "fmt"

func main() {
	var buf [12]int
	fmt.Println(buf[0])
}

// Output:
// 0
