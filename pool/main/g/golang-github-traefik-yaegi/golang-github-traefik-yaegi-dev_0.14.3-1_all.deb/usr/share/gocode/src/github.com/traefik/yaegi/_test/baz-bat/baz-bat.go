package baz

var Name = "baz-bat"
