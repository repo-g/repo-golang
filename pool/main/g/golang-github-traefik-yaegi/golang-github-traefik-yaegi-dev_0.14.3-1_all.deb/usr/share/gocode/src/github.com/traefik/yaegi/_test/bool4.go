package main

func main() {
	m := []bool{false, true}
	if m[0] {
		println(0)
	} else {
		println(1)
	}
}

// Output:
// 1
