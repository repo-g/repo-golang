package main

import (
	"fmt"
	. "net"
)

func main() {
	v := IP{}
	fmt.Println(v)
}

// Output:
// <nil>
