package main

const a = 64

var b uint = a * a / 2

func main() {
	println(b)
}

// Output:
// 2048
