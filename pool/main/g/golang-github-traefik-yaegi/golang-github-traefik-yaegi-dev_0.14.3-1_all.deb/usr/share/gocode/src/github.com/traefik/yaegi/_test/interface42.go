package main

import "fmt"

func main() {
	v := interface{}(0)

	fmt.Println(v)
}

// Output:
// 0
