package main

func main() {
	if true {
		println("ok")
	}
	println("bye")
}

// Output:
// ok
// bye
