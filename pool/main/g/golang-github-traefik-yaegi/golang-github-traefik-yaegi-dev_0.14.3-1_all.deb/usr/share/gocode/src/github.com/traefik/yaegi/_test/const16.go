package main

import (
	"fmt"
)

func main() {
	fmt.Println(7 / 3)
}

// Output:
// 2
