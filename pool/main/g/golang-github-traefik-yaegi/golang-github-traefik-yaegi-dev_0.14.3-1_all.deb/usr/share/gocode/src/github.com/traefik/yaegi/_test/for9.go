package main

func main() {
	for false {
		println("nok")
		break
	}
	println("bye")
}

// Output:
// bye
