package main

var a = [max]int{}

const max = 32

func main() {
	println(len(a))
}

// Output:
// 32
