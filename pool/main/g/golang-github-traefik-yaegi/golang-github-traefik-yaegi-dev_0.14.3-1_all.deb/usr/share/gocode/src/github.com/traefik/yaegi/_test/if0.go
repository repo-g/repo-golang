package main

func main() {
	var a bool

	if a {
		println("ok")
	} else {
		println("nok")
	}
}

// Output:
// nok
