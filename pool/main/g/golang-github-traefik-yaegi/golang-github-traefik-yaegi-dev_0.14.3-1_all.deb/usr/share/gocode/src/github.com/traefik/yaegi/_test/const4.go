package main

const (
	a = 2
	b = 3
	c
)

func main() {
	println(a, b, c)
}

// Output:
// 2 3 3
