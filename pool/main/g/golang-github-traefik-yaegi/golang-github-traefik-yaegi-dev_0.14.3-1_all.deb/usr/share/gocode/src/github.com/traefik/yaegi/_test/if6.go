package main

func main() {
	if false {
		println("nok")
	}
	println("bye")
}

// Output:
// bye
