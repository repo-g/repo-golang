package main

import "fmt"

func main() {
	m := make(map[string]interface{})
	fmt.Println(m["B"])
}

// Output:
// <nil>
