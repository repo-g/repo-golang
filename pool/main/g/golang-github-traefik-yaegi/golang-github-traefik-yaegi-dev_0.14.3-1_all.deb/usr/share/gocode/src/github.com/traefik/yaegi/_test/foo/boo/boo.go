package boo

var Boo = "Boo"

func init() { println("init boo") }
