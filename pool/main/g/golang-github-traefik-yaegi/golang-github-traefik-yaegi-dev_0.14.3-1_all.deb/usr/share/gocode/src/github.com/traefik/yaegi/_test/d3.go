package main

import "github.com/traefik/yaegi/_test/d2"

func main() {
	f := d2.F
	f()
}

// Output:
// test
