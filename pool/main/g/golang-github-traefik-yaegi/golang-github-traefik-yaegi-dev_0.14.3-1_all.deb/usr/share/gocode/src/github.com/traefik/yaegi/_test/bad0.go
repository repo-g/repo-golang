println("Hello")

// Error:
// 1:1: expected 'package', found println
