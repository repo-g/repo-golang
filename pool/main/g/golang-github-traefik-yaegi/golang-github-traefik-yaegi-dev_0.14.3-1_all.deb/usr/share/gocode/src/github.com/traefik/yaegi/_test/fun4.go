package main

func f() {}

func main() {
	f()
	println("ok")
}

// Output:
// ok
