package main

import "github.com/traefik/yaegi/_test/baz-bat"

func main() {
	println(baz.Name)
}

// Output:
// baz-bat
