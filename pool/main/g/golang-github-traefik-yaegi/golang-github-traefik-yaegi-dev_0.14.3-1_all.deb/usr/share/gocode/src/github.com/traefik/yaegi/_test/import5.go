package main

import boo "github.com/traefik/yaegi/_test/foo"

func main() { println(boo.Bar, boo.Boo, boo.Bir) }

// Output:
// init boo
// init foo
// BARR Boo Boo22
