package main

func f(i int) int { return i + 15 }

func main() {
	println(f(4))
}

// Output:
// 19
