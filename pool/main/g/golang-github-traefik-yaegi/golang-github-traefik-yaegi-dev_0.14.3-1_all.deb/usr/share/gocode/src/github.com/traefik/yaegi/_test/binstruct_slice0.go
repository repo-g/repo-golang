package main

import (
	"fmt"
	"image"
)

func main() {
	v := []image.Point{
		{X: 3, Y: 2},
	}
	fmt.Println(v)
}

// Output:
// [(3,2)]
