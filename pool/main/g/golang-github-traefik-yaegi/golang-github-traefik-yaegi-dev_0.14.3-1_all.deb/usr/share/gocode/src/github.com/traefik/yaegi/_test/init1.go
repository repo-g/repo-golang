package main

func init() {
	println("here")
}

func main() {
	init()
}

// Error:
// _test/init1.go:8:2: undefined: init
