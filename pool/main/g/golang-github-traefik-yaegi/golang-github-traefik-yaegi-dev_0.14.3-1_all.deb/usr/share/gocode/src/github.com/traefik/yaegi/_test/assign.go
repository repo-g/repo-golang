package main

func main() {
	a, b := 1, 2 // Multiple assign
	println(a, b)
}

// Output:
// 1 2
