package ct1

type Class uint

const (
	L Class = iota
	R
	AL
)
