package main

func Test() {
	println("Hello from test")
}

// Output:
//
