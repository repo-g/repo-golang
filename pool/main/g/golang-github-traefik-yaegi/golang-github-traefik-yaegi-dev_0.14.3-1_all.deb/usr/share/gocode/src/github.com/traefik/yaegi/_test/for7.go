package main

func main() {
	for i := 0; i; {
	}
}

// Error:
// 4:14: non-bool used as for condition
