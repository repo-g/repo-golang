package main

func main() {
	println("Hello")
}

// Output:
// Hello
