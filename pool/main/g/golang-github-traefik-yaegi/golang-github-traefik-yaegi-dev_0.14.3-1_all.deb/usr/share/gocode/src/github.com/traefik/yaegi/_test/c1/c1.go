package c1

import "github.com/traefik/yaegi/_test/c2"

var C1 = c2.C2 + "x"
