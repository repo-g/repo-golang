package main

import (
	"fmt"
	"math"
)

func main() {
	fmt.Println(math.Abs(-5))
}

// Output:
// 5
