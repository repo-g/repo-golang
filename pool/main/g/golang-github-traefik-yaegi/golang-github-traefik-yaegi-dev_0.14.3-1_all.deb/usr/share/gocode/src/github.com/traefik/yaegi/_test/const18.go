package main

import "time"

func main() {
	a := int64(time.Second)
	println(a)
}

// Output:
// 1000000000
