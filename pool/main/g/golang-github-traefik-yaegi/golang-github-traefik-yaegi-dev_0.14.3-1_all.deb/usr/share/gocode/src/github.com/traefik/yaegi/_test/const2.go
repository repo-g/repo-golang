package main

func main() {
	println(a)
}

const a = "hello"

// Output:
// hello
