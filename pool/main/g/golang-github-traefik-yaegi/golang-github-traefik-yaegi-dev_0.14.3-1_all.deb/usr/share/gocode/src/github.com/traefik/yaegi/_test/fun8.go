package main

func main() { println(f == nil) }

var f func()

// Output:
// true
