// +build dummy

package ct

func init() { println("hello from ct3") }
