package main

func main() {
	for range []struct{}{} {
	}
	println("ok")
}

// Output:
// ok
