package main

import "fmt"

func main() {
	f := fmt.Println
	f("Hello")
}

// Output:
// Hello
