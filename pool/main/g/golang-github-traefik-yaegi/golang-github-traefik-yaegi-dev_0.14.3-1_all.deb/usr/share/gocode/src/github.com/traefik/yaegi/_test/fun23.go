package main

func f(x int) { return x }

func main() {
	print("hello")
}

// Error:
// 3:17: too many arguments to return
