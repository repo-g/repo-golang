package main

func main() {
	var buf [bsize]byte
	println(len(buf))
}

const bsize = 10

// Output:
// 10
