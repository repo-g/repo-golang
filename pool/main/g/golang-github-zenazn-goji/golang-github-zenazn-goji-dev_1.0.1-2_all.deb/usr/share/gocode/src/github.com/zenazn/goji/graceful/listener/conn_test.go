package listener

import (
	"io"
	"testing"
)

func TestManualRead(t *testing.T) {
}

func TestAutomaticRead(t *testing.T) {
}

func TestDeadlineRead(t *testing.T) {
}

func TestDisownedRead(t *testing.T) {
}

func TestCloseConn(t *testing.T) {
}

// Regression test for issue #130.
func TestDisownedClose(t *testing.T) {
}

func TestManualReadDeadline(t *testing.T) {
}

func TestAutomaticReadDeadline(t *testing.T) {
}

func TestDeadlineReadDeadline(t *testing.T) {
}

type readerConn struct {
	fakeConn
}

func (rc *readerConn) ReadFrom(r io.Reader) (int64, error) {
	return 123, nil
}

func TestReadFrom(t *testing.T) {
}
