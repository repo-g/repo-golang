package listener

import (
	"net"
	"testing"
)

// Helper for tests acting on a single accepted connection
func singleConn(t *testing.T, m mode) (*T, *fakeConn, net.Conn) {
	l := makeFakeListener("net.Listener")
	wl := Wrap(l, m)
	c := makeFakeConn("local", "remote")

	go l.Enqueue(c)
	wc, err := wl.Accept()
	if err != nil {
		t.Fatalf("error accepting connection: %v", err)
	}
	return wl, c, wc
}

func TestAddr(t *testing.T) {
}

func TestBasicCloseIdle(t *testing.T) {
}

func TestMark(t *testing.T) {
}

func TestDisown(t *testing.T) {
}

func TestDrain(t *testing.T) {
}

func TestDrainAll(t *testing.T) {
}

func TestErrors(t *testing.T) {
	t.Parallel()
	_, c, wc := singleConn(t, Manual)
	if err := Disown(c); err == nil {
		t.Error("expected error when disowning unmanaged net.Conn")
	}
	if err := MarkIdle(c); err == nil {
		t.Error("expected error when marking unmanaged net.Conn idle")
	}
	if err := MarkInUse(c); err == nil {
		t.Error("expected error when marking unmanaged net.Conn in use")
	}

	if err := Disown(wc); err != nil {
		t.Fatalf("unexpected error disowning socket: %v", err)
	}
	if err := Disown(wc); err == nil {
		t.Error("expected error disowning socket twice")
	}
}

func TestClose(t *testing.T) {
}
