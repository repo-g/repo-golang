package listener

import (
	"runtime"
	"testing"
)

func init() {
	// Just to make sure we get some variety
	runtime.GOMAXPROCS(4 * runtime.NumCPU())
}

// Chosen by random die roll
const seed = 4611413766552969250

// This is mostly just fuzzing to see what happens.
func TestRace(t *testing.T) {
}
