// Package mutil contains various functions that are helpful when writing http
// middleware.
package mutil
