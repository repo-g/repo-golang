// Package xpc provides minimal OS X XPC support required for gatt
//
// This is adapted from [goble], by Raffaele Sena.
//
//     http://godoc.org/github.com/raff/goble
//     https://github.com/raff/goble

package xpc
