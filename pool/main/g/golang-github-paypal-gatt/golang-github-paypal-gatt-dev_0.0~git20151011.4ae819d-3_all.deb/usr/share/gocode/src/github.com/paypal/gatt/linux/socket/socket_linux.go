// +build linux

package socket

import "syscall"

const AF_BLUETOOTH = syscall.AF_BLUETOOTH
