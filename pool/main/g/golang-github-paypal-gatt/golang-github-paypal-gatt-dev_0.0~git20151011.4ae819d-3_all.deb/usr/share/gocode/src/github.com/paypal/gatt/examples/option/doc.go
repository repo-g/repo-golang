// Package option wraps the platform specific options to help
// users creating cross-platform programs.
package option
