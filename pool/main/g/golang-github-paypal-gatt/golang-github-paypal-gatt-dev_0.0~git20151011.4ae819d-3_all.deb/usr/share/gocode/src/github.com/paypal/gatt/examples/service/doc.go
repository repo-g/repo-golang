// Package service provides a collection of sample services for demostrating purpose.
package service
