// Copyright 2020 Canonical Ltd.
// Licensed under the LGPLv3, see LICENCE file for details.

// +build go1.13
// +build !go1.12,!go1.14

package checkers

const (
	flagRO flag = 1<<5 | 1<<6
)
