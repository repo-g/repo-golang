/*
Package sockjs is a server side implementation of sockjs protocol.
*/

package sockjs
