// Package genetlink implements generic netlink interactions and data types.
//
// If you have any questions or you'd like some guidance, please join us on
// Gophers Slack (https://invite.slack.golangbridge.org) in the #networking
// channel!
package genetlink
