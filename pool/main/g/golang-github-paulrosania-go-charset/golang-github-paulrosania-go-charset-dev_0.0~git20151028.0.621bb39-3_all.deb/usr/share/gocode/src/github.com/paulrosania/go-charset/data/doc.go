// The data package embeds all the charset
// data files as Go data. It registers the data with the charset
// package as a side effect of its import. To use:
//
//	import _ "github.com/paulrosania/go-charset"
package data
