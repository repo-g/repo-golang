// Tideland Go Libray - Feed Utils
//
// Copyright (C) 2012-2017 Frank Mueller / Tideland / Oldenburg / Germany
//
// All rights reserved. Use of this source code is governed
// by the new BSD license.

// Package utils of the Tideland Go Libray feeds contains several helpers
// for the other feed packages.
package utils

// EOF
