// Tideland Go Library - Numerics
//
// Copyright (C) 2009-2017 Frank Mueller / Tideland / Oldenburg / Germany
//
// All rights reserved. Use of this source code is governed
// by the new BSD license.

// Package numerics of the Tideland Go Library contains some functions
// to support statistical analysis.
package numerics

// EOF
