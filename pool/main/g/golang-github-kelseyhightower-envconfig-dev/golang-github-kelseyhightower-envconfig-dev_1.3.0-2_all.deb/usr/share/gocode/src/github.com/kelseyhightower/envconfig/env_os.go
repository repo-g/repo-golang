// +build appengine

package envconfig

import "os"

var lookupEnv = os.LookupEnv
