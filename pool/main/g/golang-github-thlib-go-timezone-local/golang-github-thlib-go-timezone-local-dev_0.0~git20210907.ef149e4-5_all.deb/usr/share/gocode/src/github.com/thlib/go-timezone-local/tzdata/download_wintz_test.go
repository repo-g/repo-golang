package tzdata

import (
	"os"
	"testing"
)

func TestDownloadWindowsZones(t *testing.T) {
	if os.Getenv("AUTOPKGTEST_TMP") == "" {
		t.Skip("skip test as Internet access is disallowed during Debian package build")
	}
	_, err := DownloadWindowsZones()
	if err != nil {
		t.Errorf("error: %v", err)
	}
}
