package tzdata

import (
	"bytes"
	"os"
	"testing"
)

func TestUpdateWindowsTZMapping(t *testing.T) {
	if os.Getenv("AUTOPKGTEST_TMP") == "" {
		t.Skip("skip test as Internet access is disallowed during Debian package build")
	}
	var buf bytes.Buffer
	err := UpdateWindowsTZMapping(&buf)
	if err != nil {
		t.Errorf("error: %v", err)
	}
}
