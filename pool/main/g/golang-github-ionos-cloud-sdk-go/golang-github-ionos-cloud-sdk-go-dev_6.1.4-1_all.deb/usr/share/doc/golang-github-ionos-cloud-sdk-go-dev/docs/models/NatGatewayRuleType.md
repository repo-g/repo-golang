# NatGatewayRuleType

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|



