// +build windows

package fqdn

var hostsPath = `C:\Windows\System32\drivers\etc\hosts` //nolint:gochecknoglobals
