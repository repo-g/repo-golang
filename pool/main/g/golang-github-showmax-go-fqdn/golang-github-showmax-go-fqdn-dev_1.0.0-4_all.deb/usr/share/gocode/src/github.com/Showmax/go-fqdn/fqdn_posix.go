// +build !windows

package fqdn

var hostsPath = "/etc/hosts" //nolint:gochecknoglobals
