package template

// GeneratedType is a placeholder in the implementation files for what will be replaced by code generation
type GeneratedType interface{}
