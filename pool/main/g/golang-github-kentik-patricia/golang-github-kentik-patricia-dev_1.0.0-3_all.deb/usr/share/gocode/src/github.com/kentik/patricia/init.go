package patricia

func init() {
	initBuildLeftMasks()
}
