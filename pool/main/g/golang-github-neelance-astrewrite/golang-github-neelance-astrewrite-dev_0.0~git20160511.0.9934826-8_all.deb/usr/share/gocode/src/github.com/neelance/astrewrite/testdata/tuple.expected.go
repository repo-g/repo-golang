package main

func main() {
	_1, _2 := f()
	g(_1, _2)
}

func f() (int, int) {
	return 0, 0
}

func g(x, y int) {
}
