// +build windows

package dexlogconfig

func openSyslog()  {}
func openJournal() {}
