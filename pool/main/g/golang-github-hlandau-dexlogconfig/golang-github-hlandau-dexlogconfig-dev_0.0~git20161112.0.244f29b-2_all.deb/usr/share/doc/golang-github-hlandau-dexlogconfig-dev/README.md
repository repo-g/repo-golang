# dexlogconfig

This is a policy package to configure [xlog](https://github.com/hlandau/xlog)
as I like it. It is used in my daemons, and provides an example of how to
configure xlog.
