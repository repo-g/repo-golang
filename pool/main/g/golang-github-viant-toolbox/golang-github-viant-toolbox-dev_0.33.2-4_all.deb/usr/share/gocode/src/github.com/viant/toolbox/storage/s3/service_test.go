package s3_test

import (
	"testing"
)

func TestService_List(t *testing.T) {

	/*	fmt.Print("Has service\n")
		config := &aws.Config{
			Region: "",
			Key:    "",
			Secret: "",
		}

		service := aws.NewService(config)
		assert.NotNil(t, service)

		result, err := service.List("<S3 bucket>")
		assert.Nil(t, err)

		for _, o := range result {
			fmt.Printf("R: %v\n", o.URL())

		}

		obj, err := service.StorageObject("<S3 bucket>")
		assert.Nil(t, err)
		assert.NotNil(t, obj)

		assert.Nil(t, service.Delete(obj))*/
}
