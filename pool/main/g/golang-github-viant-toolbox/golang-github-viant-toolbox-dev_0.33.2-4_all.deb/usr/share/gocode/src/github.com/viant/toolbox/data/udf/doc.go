package udf

//Doc udf documentation
type Doc struct {
	Description string
	Example     string
}
