package gs

import (
	"testing"
)

func TestService_List(t *testing.T) {

	/*	credential := option.WithServiceAccountFile("<Secret file path>")
		service := gs.NewService(credential)
		assert.NotNil(t, service)
		objects, err := service.List("<GCS bucket>")
		assert.Nil(t, err)
		for _, o := range objects {
			fmt.Printf("%v\n", o.URL())
		}
		object, err := service.StorageObject("<GCS bucket>")
		assert.Nil(t, err)
		assert.NotNil(t, object)
		err = service.Delete(object)
		assert.Nil(t, err)*/

}
