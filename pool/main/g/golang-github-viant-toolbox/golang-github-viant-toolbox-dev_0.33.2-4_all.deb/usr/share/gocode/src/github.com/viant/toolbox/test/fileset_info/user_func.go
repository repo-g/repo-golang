package fileset_info

import "fmt"

//Test represents a test method
func (u *User) Test2() {
	fmt.Printf("Abc %v", u)
}
