package dynect

// Zone struct to hold record details
type Zone struct {
	Serial      string
	SerialStyle string
	Zone        string
	Type        string
}
