package dynect

import (
	"testing"

	"github.com/dnaeon/go-vcr/recorder"
)

// test helper to setup convenient client with vcr cassette
func withConvenientClient(cassetteName string, f func(*ConvenientClient)) {
	withCassette(cassetteName, func(r *recorder.Recorder) {
		c := NewConvenientClient(DynCustomerName)
		c.SetTransport(r)
		c.Verbose(true)

		f(c)
	})
}

// test helper to setup authenticated convenient client with vcr cassette
func testWithConvenientClientSession(cassetteName string, t *testing.T, f func(*ConvenientClient)) {
	withConvenientClient(cassetteName, func(c *ConvenientClient) {
		if err := c.Login(DynUsername, DynPassword); err != nil {
			t.Error(err)
		}

		defer func() {
			if err := c.Logout(); err != nil {
				t.Error(err)
			}
		}()

		f(c)
	})
}

func TestConvenientLoginLogout(t *testing.T) {
}

func TestConvenientGetA(t *testing.T) {
}

func TestConvenientGetANotFound(t *testing.T) {
}

func TestConvenientGetCNAME(t *testing.T) {
}

func TestConvenientCreateMX(t *testing.T) {
}

func TestConvenientCreateZone(t *testing.T) {
}

func TestConvenientDeleteZone(t *testing.T) {
}

func TestConvenientDeleteSubZone(t *testing.T) {
}
