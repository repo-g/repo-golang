// +build !darwin,!freebsd,!netbsd,!openbsd,!linux

package flags

const (
	TIOCGWINSZ = 0
)
