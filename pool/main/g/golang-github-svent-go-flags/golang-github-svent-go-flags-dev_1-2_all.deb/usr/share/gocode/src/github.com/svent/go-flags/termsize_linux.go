// +build linux

package flags

const (
	TIOCGWINSZ = 0x5413
)
