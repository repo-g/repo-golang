package flags

func getTerminalColumns() int {
	return 80
}
