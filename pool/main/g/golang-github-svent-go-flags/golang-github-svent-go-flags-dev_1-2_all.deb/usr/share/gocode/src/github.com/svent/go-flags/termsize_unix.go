// +build darwin freebsd netbsd openbsd

package flags

const (
	TIOCGWINSZ = 0x40087468
)
