Native Go Zookeeper Client Library
===================================

[![Build Status](https://travis-ci.org/samuel/go-zookeeper.png)](https://travis-ci.org/samuel/go-zookeeper)

Documentation: http://godoc.org/github.com/samuel/go-zookeeper/zk

License
-------

3-clause BSD. See LICENSE file.
