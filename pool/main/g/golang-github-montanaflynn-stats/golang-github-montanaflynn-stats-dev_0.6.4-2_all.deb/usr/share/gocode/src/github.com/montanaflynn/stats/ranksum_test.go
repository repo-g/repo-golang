package stats_test

// import (
// 	"testing"
// )
//
// //   >>> y1=[125,115,130,140,140,115,140,125,140,135]
// // >>> y2=[110,122,125,120,140,124,123,137,135,145]
// // >>> ss.wilcoxon(y1, y2)
// // (18.0, 0.5936305914425295)
//
// // func ExampleWilcoxonRankSum() {
// // 	t, p, err := WilcoxonRankSum([]float64{3.0, 1.0, 0.2}, []float64{3.1, 1.2, 1.2})
// // 	fmt.Println(t, p, err)
// // 	// Output: 18.0, 0.5936305914425295, nil
// //
// // }
//
// func TestRanked(t *testing.T) {
//
// 	var data = []float64{0.1, 3.2, 3.2}
//
// 	StandardRank(data)
// 	// show := func(name string, fn func(rankable) []float64) {
// 	// 	fmt.Println(name, "Ranking:")
// 	// 	r := fn(data)
// 	// 	for i, d := range data {
// 	// 		fmt.Printf("%4v\n", r[i])
// 	// 	}
// 	// }
// 	//
// 	// sort.Sort(data)
// 	// show("Standard", StandardRank)
// 	// show("\nModified", ModifiedRank)
// 	// show("\nDense", DenseRank)
// 	// show("\nOrdinal", OrdinalRank)
// 	// show("\nFractional", FractionalRank)
//
// }
