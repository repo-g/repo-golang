// +build js

package testing

func callerName(skip int) string {
	// TODO: Implement if possible.
	return "<unknown>"
}
