// +build js

package bytes_test

import (
	"testing"
)

func TestEqualNearPageBoundary(t *testing.T) {
	t.Skip()
}
