package service

//
// func TestAppAgent(t *testing.T) {
// 	a := createTestApp(t)
// 	defer a.Close()
//
// 	ag, err := agent.NewAgent1("org.bluez", "/org/bluez/agent/simple0")
// 	if err != nil {
// 		t.Fatal(err)
// 	}
//
// 	err = ag.RequestConfirmation("/org/bluez/hci0/app0", 123456)
// 	if err != nil {
// 		t.Fatal(err)
// 	}
//
// }
