package sensortag

func getOptions() map[string]interface{} {
	options := make(map[string]interface{})
	return options
}
