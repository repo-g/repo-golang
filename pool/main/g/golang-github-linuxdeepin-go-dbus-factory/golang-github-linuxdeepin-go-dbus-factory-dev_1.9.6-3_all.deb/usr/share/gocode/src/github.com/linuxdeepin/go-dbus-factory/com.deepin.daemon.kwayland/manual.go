package kwayland

type Rect struct {
	X, Y, Width, Height int32
}
