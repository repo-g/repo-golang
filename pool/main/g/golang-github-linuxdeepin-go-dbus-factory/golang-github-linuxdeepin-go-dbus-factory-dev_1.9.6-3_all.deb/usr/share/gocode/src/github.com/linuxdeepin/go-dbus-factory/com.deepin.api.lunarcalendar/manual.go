package lunarcalendar

type DayFestival struct {
	Year int32
	Month int32
	Day int32
	Festivals []string
}
