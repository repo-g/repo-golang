// +build debug0

package pdebug

var Trace = true

