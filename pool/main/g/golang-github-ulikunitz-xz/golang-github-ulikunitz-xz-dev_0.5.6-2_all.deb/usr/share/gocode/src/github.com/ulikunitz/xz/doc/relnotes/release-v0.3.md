# Release Notes v0.3

This release provides an lzmago command that provides a complete set of
flags to decompress and compress .lzma files. It is interoperable with
the lzma tool from the xz package.

The release changed the lzma implementation to support later
optimizations of the compression algorithm as well as the plumbing
required to support the LZMA2 format.

The release provides the ground work to provide full support for the
full xz specification.
