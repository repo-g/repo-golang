# Release Notes v0.5.2

The realease fixes issue #12 related an XZ stream with no data.

Many thanks to Tomasz Kłak for reporting the issue.
