package hcloud

// Resource defines the schema of a resource.
type Resource struct {
	ID   int
	Type string
}
