// Copyright 2016 Canonical ltd.
// Copyright 2016 Cloudbase solutions
// Licensed under the LGPLv3, see LICENCE file for details.

package cert

var (
	CertSubjAltName           = subjAltName
	CertGetUPNExtenstionValue = getUPNExtensionValue
)
