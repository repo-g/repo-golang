// Copyright 2012, 2013 Canonical Ltd.
// Licensed under the LGPLv3, see LICENCE file for details.

package registry

var (
	DescriptionFromVersions = descriptionFromVersions
)
