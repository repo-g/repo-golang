// Copyright 2013 Canonical Ltd.
// Licensed under the LGPLv3, see LICENCE file for details.

package tailer

var (
	BufferSize    = &bufferSize
	NewTestTailer = newTailer
)
