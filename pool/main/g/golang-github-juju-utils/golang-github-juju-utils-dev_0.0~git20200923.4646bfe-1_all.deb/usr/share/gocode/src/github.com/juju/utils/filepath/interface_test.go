// Copyright 2015 Canonical Ltd.
// Licensed under the LGPLv3, see LICENCE file for details.

package filepath

var _ Renderer = (*UnixRenderer)(nil)
var _ Renderer = (*WindowsRenderer)(nil)
