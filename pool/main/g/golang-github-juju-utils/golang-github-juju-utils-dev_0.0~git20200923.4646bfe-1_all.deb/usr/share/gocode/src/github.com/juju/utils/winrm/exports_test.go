// Copyright 2016 Canonical ltd.
// Copyright 2016 Cloudbase solutions
// Licensed under the LGPLv3, see licence file for details.
package winrm

var (
	ErrNoX509Folder = errNoX509Folder
	ErrNoClientCert = errNoClientCert
)
