// Copyright 2014 Cloudbase Solutions SRL
// Licensed under the LGPLv3, see LICENCE file for details.

package symlink

var (
	GetLongPathAsString = getLongPathAsString
)
