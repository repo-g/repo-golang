package io_prometheus_client

//go:generate protoc --proto_path=../io/prometheus/client --go_out=paths=source_relative,Mgoogle/protobuf/timestamp.proto=github.com/golang/protobuf/ptypes/timestamp:. metrics.proto
