package githubv4

const (
	// IssueHunt funding platform.
	//
	// Deprecated: Use FundingPlatformIssueHunt instead. This will be deleted after 2022-11-19.
	FundingPlatformIssuehunt = FundingPlatformIssueHunt
)
