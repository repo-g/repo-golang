// Package custom defines interfaces to interact
// with custom entities in Kong.
package custom
