// Package kong provides Go bindings to Kong's RESTful
// Admin API.
package kong
