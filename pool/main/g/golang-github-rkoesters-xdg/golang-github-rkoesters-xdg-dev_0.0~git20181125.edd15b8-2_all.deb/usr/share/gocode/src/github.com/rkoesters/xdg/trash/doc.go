// Package trash provides easy access to the trash bin. For more
// information, see the trash spec:
// https://standards.freedesktop.org/trash-spec/trashspec-latest.html
//
// TODO: Make New work.
package trash
