// Package desktop implements the Desktop Entry Spec. For more
// information, please see the spec:
// http://standards.freedesktop.org/desktop-entry-spec/desktop-entry-spec-latest.html
package desktop
