package desktop

import ()

// Launch TODO
func (de *Entry) Launch(uris ...string) error {
	panic("not implemented")
}
