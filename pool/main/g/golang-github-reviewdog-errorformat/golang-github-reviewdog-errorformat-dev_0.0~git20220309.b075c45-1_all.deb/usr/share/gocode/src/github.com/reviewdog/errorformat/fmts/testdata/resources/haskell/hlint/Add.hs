module Add where

add :: Integer -> Integer -> Integer
add (x) y = x + y
