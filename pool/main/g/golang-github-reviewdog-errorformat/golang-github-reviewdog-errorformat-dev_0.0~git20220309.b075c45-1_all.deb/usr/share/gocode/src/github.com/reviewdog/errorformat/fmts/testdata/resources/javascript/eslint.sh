#!/bin/bash
eslint ./eslint.js
