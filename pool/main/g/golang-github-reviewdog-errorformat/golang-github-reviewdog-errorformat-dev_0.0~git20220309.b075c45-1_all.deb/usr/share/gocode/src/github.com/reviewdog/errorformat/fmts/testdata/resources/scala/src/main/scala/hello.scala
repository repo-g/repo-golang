
object Main extends App {
  println("hello")
}

object foo {
  println("hello")
}

