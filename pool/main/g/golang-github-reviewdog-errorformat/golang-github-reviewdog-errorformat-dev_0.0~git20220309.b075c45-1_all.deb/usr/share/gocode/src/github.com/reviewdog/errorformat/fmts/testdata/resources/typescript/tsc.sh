#!/bin/bash
tsc --noImplicitAny tsc.ts
