#!/bin/bash
hlint ./Add.hs
