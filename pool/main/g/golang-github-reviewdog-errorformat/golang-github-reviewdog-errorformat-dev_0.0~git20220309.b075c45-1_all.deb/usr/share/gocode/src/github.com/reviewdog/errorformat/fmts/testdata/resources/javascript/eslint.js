
function unusedf(a) {
  var x = "double quote";
}

var unusedvar = 1 // missing semicolon


