#!/bin/bash
eslint -f compact ./eslint.js
