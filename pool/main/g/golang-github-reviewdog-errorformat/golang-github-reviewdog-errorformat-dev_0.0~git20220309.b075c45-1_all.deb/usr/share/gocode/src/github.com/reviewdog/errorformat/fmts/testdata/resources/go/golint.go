package test

var V int

var NewError1 int

// invalid func comment
func F() {
}

// invalid func comment2
func F2() {
}
