declare function cond(): boolean;

function f5(y) {
    let x = [5, "hello"];  // Non-evolving array
    x.push(true);          // Error
}

function f(n: number) {
}

error
