//go:build packetioSizeHardlimit
// +build packetioSizeHardlimit

package packetio

const sizeHardLimit = true
