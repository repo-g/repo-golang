package syscallx

/* This is the source file for msync_*.go, to regenerate run

   ./generate

*/

//sys Msync(b []byte, flags int) (err error)
