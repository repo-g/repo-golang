// +build go1.11

package forward

func (f *Forwarder) postConfig() {}
