// this exists as a downstream of fake/dep
package dependent

import _ "fake/dep"
