// this exists as a fake vendored dependency so that the vendor path canonicalization
// can be reliably tested
package dep
