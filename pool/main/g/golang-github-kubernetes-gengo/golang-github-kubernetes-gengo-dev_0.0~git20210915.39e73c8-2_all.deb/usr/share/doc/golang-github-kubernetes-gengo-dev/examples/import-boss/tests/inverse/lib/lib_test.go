package lib

import (
	_ "k8s.io/gengo/examples/import-boss/tests/inverse/lib/nonprod"
)
