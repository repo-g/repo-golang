package a

import (
	_ "k8s.io/gengo/examples/import-boss/tests/rules/b"
)
