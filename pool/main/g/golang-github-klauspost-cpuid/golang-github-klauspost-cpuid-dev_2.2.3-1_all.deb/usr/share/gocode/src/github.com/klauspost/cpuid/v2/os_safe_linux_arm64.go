// Copyright (c) 2021 Klaus Post, released under MIT License. See LICENSE file.

//go:build nounsafe
// +build nounsafe

package cpuid

var hwcap uint
