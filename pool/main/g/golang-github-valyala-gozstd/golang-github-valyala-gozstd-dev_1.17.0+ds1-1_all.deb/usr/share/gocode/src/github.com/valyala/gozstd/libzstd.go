package gozstd

/*
#cgo LDFLAGS: -lzstd
*/
import "C"
