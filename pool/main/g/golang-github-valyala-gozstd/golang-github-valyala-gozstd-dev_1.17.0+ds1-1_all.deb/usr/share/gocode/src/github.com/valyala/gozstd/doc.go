// Package gozstd is Go wrapper for zstd.
//
// Gozstd is used in https://github.com/VictoriaMetrics/VictoriaMetrics .
package gozstd
