// Package proxy provides a proxy for the Ace template engine.
// The proxy caches the options for the Ace template engine
// so that you don't have to specify them every time calling
// the Ace APIs.
package proxy
