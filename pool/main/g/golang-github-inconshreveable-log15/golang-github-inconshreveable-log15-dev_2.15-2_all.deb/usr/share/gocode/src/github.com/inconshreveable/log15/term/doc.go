// Package term provides utilities for working with terminals.
//
// Deprecated: This package is no longer used by log15. Please use
// github.com/mattn/go-isatty instead.
package term
