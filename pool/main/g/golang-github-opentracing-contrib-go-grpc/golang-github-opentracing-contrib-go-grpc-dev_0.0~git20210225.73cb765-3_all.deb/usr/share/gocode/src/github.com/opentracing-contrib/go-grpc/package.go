// Package otgrpc provides OpenTracing support for any gRPC client or server.
//
// See the README for simple usage examples:
// https://github.com/opentracing-contrib/go-grpc/README.md
package otgrpc
