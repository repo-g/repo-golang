// Package gohtml provides an HTML formatting function.
package gohtml
