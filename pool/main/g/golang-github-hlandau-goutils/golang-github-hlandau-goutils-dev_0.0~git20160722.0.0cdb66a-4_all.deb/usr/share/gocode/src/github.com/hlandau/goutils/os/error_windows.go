// +build windows

package os

func isNotEmpty(err error) bool {
	return false // TODO
}
