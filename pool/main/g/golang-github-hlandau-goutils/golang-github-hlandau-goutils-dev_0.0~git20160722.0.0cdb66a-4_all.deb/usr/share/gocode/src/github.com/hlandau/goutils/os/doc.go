// Package os provides additional OS abstraction functionality for functions
// not provided by the Go standard library.
package os
