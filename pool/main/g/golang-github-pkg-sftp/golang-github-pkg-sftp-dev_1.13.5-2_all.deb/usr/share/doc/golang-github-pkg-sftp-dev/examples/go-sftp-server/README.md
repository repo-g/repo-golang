Example SFTP server implementation
===

In order to use this example you will need an RSA key.

On linux-like systems with openssh installed, you can use the command:

```
ssh-keygen -t rsa -f id_rsa
```

Then you will be able to run the sftp-server command in the current directory.
