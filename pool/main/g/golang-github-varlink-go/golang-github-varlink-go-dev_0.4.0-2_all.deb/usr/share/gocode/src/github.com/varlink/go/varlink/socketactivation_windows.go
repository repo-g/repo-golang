package varlink

import "net"

func activationListener() net.Listener {
	return nil
}
