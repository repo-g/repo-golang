package restruct

// RegisterArrayType is deprecated; it is now a noop.
func RegisterArrayType(array interface{}) {
}
