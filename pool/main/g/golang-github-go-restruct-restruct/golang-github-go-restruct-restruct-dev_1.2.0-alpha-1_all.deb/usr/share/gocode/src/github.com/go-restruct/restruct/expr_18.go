// +build !go1.9

package restruct

import (
	"github.com/go-restruct/restruct/expr"
)

var exprStdLib = map[string]expr.Value{}
