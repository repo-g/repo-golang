package ace

import "testing"

func Test_newElement(t *testing.T) {

}
