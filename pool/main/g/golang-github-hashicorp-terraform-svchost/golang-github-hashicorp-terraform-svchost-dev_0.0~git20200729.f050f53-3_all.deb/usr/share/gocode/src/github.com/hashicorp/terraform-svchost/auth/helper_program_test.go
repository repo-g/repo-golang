package auth

import (
	"os"
	"path/filepath"
	"testing"

)

func TestHelperProgramCredentialsSource(t *testing.T) {
	wd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}

	program := filepath.Join(wd, "testdata/test-helper")
	t.Logf("testing with helper at %s", program)

}
