#ifndef __NET_IP_H__
#define __NET_IP_H__

char *get_iface_ip(const char *iface);

#endif
