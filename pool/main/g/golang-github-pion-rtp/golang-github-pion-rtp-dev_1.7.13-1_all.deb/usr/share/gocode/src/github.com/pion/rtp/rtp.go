// Package rtp provides RTP packetizer and depacketizer
package rtp
