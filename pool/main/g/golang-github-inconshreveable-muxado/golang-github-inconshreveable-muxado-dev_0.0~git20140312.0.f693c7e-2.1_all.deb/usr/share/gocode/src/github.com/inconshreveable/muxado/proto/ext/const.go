package ext

import (
	"github.com/inconshreveable/muxado/proto"
)

const (
	heartbeatExtensionType = proto.MinExtensionType + iota
)
