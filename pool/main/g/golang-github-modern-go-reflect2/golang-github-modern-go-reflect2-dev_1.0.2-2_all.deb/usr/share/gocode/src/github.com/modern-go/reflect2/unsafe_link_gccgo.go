//go:build gccgo
// +build gccgo

package reflect2

import "unsafe"

//go:linkname unsafe_New reflect.unsafe__New
func unsafe_New(rtype unsafe.Pointer) unsafe.Pointer

//go:linkname unsafe_NewArray reflect.unsafe__NewArray
func unsafe_NewArray(rtype unsafe.Pointer, length int) unsafe.Pointer
