// A package file to ensure that go modules will recognize the dependency correctly.
package lightstep_tracer_common
