// +build !darwin

package main

func hostInit() {}
