package element

// DisposalEligiblePersonsDataElement represents a DataElement
type DisposalEligiblePersonsDataElement struct {
	DataElement
}

// DisposalEligiblePersonDataElement represents a DataElement
type DisposalEligiblePersonDataElement struct {
	DataElement
}
