package bankinfo

type bankData struct {
	BIC     string
	BankID  string
	Version int
	URL     string
}
