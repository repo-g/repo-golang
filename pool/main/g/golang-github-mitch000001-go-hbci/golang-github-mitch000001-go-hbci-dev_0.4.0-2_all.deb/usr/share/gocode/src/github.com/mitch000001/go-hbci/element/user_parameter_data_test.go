package element

import "testing"

func TestAllowedBusinessTransactionsDataElement(t *testing.T) {
}
