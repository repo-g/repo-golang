/*

Package proto provides kafka binary protocol implementation.

*/
package proto
