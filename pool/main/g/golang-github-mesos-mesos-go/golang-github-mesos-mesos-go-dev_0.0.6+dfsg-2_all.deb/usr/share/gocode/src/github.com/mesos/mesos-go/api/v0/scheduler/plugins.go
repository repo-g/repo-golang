package scheduler

import (
	_ "github.com/mesos/mesos-go/api/v0/auth/sasl"
	_ "github.com/mesos/mesos-go/api/v0/auth/sasl/mech/crammd5"
	_ "github.com/mesos/mesos-go/api/v0/detector/zoo"
)
