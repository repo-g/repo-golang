/*
Package upid defines the UPID type and some utilities of the UPID.
*/
package upid
