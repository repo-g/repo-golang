package mesosutil

const (
	// MesosVersion indicates the supported mesos version.
	MesosVersion = "0.24.0"
)
