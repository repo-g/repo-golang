package constants

const Version = "2.5.2"
