//go:generate sh -c "go run mkntstatus.go > ntstatus.go && gofmt -w ntstatus.go"

package erref
