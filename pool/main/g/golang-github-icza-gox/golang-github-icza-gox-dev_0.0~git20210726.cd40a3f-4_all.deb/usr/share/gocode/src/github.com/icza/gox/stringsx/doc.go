/*

Package stringsx contains string utilities.
It means to be a complement to the standard strings package.

*/
package stringsx
