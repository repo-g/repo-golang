/*

Package osx contains operating system utilities.
It means to be a complement to the standard os package.

*/
package osx
