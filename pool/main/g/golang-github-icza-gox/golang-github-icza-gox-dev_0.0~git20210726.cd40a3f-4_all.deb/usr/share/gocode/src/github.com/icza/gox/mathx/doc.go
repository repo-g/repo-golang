/*

Package mathx contains math utilities.
It means to be a complement to the standard math package.

*/
package mathx
