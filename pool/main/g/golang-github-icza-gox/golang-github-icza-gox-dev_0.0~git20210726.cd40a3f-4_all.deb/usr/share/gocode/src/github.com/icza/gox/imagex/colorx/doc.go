/*

Package colorx contains color utilities.
It means to be a complement to the standard image/color package.

*/
package colorx
