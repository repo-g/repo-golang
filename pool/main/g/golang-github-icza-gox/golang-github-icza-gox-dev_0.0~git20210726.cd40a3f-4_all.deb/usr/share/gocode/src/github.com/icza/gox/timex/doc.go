/*

Package timex contains time and duration related calculations and utilities.
It means to be a complement to the standard time package.

*/
package timex
