/*

Package randx contains random-related utilities.
It means to be a complement to the standard math/rand package.

*/
package randx
