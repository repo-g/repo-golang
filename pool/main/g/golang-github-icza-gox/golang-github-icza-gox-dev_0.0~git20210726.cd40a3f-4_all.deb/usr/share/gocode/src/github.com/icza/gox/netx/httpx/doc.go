/*

Package httpx contains HTTP utilities.
It means to be a complement to the standard net/http package.

*/
package httpx
