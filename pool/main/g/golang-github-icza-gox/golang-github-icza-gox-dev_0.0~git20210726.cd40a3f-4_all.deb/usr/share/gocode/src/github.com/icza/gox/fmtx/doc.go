/*

Package fmtx contains formatting utilities.
It means to be a complement to the standard fmt package.

*/
package fmtx
