// Package ndp implements the Neighbor Discovery Protocol, as described in
// RFC 4861.
package ndp

//go:generate stringer -type=Preference -output=string.go
