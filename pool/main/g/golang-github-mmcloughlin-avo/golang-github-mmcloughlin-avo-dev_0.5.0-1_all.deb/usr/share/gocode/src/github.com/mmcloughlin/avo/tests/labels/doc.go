// Package labels tests for cleanup of redundant labels.
package labels
