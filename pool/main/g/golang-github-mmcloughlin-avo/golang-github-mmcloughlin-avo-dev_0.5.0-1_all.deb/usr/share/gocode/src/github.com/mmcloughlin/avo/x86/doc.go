// Package x86 provides constructors for all x86-64 instructions.
package x86
