// Package issue89 tests register allocation with self-cancelling inputs.
package issue89
