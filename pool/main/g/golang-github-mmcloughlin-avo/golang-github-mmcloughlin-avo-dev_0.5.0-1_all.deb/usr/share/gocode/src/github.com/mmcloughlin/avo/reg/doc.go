// Package reg provides types for physical and virtual registers, and definitions of x86-64 register families.
package reg
