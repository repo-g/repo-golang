// Package ir provides the intermediate representation of avo programs.
package ir
