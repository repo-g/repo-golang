package x86

//go:generate avogen -output zoptab.go optab
//go:generate avogen -output zctors.go ctors
//go:generate avogen -output zctors_test.go ctorstest
