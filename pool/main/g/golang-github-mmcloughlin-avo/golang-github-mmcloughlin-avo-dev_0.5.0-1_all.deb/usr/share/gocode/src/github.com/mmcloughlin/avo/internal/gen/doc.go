// Package gen provides code generators based on the instruction database.
package gen
