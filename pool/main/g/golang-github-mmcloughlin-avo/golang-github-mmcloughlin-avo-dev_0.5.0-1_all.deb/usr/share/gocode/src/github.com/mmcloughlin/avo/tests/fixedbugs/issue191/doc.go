// Package issue191 tests for correct argument size for a function taking a
// single uint16 argument. Prior to the fix, this test case triggered an asmdecl
// error.
package issue191
