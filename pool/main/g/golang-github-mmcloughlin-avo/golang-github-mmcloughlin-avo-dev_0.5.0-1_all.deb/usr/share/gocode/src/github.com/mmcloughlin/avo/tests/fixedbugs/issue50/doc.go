// Package issue50 tests for 32-bit MOVD/MOVQ instruction forms.
package issue50
