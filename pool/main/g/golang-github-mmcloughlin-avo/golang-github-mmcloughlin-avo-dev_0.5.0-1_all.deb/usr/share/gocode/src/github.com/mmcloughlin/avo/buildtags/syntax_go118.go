//go:build go1.18
// +build go1.18

package buildtags

const (
	plusbuild = false
	gobuild   = true
)
