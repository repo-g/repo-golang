// Package issue336 tests boolean arguments and return values.
//
// Issue #336 pointed out that move deduction for boolean types was not present.
package issue336
