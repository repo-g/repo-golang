// Package inst is the avo instruction database.
package inst
