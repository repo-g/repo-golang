// Package custom tests overriding package name with the CLI.
package custom
