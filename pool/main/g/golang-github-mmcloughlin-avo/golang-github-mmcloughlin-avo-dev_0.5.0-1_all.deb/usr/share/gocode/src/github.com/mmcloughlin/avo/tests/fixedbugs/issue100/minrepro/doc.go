// Package minrepro contains a minimal reproducer for the aliased register allocation bug in issue 100.
package minrepro
