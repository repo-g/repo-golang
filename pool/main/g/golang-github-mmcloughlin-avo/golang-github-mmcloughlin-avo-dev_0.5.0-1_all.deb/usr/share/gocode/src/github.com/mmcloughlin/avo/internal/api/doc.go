// Package api determines the API of avo instruction constructors.
package api
