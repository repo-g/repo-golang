//go:build go1.17 && !go1.18
// +build go1.17,!go1.18

package buildtags

const (
	plusbuild = true
	gobuild   = true
)
