// Package issue76 deliberately produces redundant MOV instructions.
//
// The intent is to confirm redundant self-move instructions are correctly removed.
package issue76
