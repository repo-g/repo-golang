// Package opcodescsv extracts data from the Go x86.csv database.
package opcodescsv
