package main

import "github.com/lensesio/schema-registry/schema-registry-cli/cmd"

func main() {
	cmd.Execute()
}
