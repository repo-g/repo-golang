// Package ethtool allows control of the Linux ethtool generic netlink
// interface. For more information, see:
// https://www.kernel.org/doc/html/latest/networking/ethtool-netlink.html.
package ethtool
