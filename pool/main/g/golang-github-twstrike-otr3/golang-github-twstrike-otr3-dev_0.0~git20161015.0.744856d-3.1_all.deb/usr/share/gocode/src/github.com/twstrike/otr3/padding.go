package otr3

func (c *Conversation) processPaddingTLV(tlv, dataMessageExtra) (toSend *tlv, err error) {
	return nil, nil
}
