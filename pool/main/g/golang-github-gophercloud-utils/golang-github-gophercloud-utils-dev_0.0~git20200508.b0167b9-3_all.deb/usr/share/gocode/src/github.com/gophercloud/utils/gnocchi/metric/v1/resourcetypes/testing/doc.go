// resource types unit tests
package testing
