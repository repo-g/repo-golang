package main

import "github.com/ivanpirog/coloredcobra/example/cmd"

func main() {
	cmd.Execute()
}
