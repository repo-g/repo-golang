/*
Package xdg Light weight helper functions in golang to get config, data and cache files according to the XDG Base Directory Specification
*/
package xdg
