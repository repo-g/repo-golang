// +build cgo

package buildinfo

const Cgo = true
