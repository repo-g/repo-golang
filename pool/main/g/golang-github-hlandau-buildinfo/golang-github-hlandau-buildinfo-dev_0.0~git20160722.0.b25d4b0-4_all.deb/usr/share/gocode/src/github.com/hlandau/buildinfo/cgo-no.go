// +build !cgo

package buildinfo

const Cgo = false
