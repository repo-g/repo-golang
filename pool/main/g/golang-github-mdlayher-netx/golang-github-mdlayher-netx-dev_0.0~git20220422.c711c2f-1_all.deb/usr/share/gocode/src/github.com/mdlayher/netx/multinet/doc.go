// Package multinet allows combining multiple package net types into one.
package multinet
