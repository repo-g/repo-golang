// Package rfc4193 implements Unique Local IPv6 Unicast Address prefix
// generation, as described in RFC 4193.
package rfc4193
