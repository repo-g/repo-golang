// Copyright 2016-2017 Canonical Ltd.
// Licensed under the LGPLv3, see LICENCE file for details.

package mutex

var (
	// Export the Envars so we can test it via mocks
	Envars = &envars
)
