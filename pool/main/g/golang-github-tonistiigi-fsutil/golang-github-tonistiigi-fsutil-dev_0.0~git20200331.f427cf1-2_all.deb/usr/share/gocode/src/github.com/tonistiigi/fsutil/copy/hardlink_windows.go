package fs

import "os"

func getLinkInfo(fi os.FileInfo) (uint64, bool) {
	return 0, false
}
