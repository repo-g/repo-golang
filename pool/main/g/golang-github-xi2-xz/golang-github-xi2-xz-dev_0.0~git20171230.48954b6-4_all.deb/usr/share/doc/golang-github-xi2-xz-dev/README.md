# Xz

Package xz implements XZ decompression natively in Go.

Documentation at <https://godoc.org/github.com/xi2/xz>.

Download and install with `go get github.com/xi2/xz`.

If you need compression as well as decompression, you might want to
look at <https://github.com/ulikunitz/xz>.
