package seccomp

const (
	seccompOverwrite = "overwrite"
	seccompAppend    = "append"
	nothing          = "nothing"
)
