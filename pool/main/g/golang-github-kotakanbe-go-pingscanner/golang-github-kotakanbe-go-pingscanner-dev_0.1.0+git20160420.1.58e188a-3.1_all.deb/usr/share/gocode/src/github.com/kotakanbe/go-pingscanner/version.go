package pingscanner

// Name ... Name
const Name string = "go-pingscanner"

// Version ... Version
const Version string = "0.1.0"
