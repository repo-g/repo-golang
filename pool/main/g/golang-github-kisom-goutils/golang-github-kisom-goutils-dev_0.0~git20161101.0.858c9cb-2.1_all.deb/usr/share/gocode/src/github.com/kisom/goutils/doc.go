// Package goutils is a top-level package containing a number of utility
// libraries and command-line programs.
package goutils
